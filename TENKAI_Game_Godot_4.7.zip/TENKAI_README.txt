TENKAI 0.6 PLAYABLE — Open project.godot in Godot 4.7.2.
See CHANGELOG_0.6_PLAYABLE.md for details.
